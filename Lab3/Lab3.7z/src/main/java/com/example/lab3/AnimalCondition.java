package com.example.lab3;

public enum AnimalCondition{
    Zdrowe, Chore, WTrakcieAdopcji, Kwarantanna
}